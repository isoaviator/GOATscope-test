# GOATscope – EuroScope Plugin

Displays full airport names and IFR altitude rule checks in a pop-up
whenever you click a flight's GOATscope tag item.

---

## What it shows

| Field | Description |
|---|---|
| A/C Type | Aircraft ICAO type code from the flight plan |
| Rules | Flight rules (IFR / VFR / mixed) |
| DEP | Departure ICAO + full airport name |
| ARR | Destination ICAO + full airport name |
| Altitude | Filed altitude (feet + FL) |
| Track | Great-circle true bearing dep→arr |
| ICAO Semicircular | Odd thousands eastbound / even westbound check |
| FAA Hemispheric | Same logic, FAA IFR phrasing |

---

## Build instructions

### Prerequisites
- **Visual Studio 2022** (Community is fine) with the **Desktop development
  with C++** workload installed.
- **EuroScope Plugin SDK** – download from  
  https://www.euroscope.hu/wp/es-plugin-developer-documentation/  
  Unzip it so the folder `EuroScopePluginSDK/` sits next to `GOATscope/`.

### Folder layout expected

```
YourProjects/
├── EuroScopePluginSDK/      ← SDK folder (contains EuroScopePlugIn.h etc.)
│   └── EuroScopePlugIn.h
└── GOATscope/               ← this repo
    ├── GOATscope.vcxproj
    ├── include/
    │   ├── GOATscope.h
    │   └── AirportDB.h
    └── src/
        ├── GOATscope.cpp
        └── GOATscope.def
```

### Steps

1. Open `GOATscope.vcxproj` in Visual Studio.
2. Set the build target to **Release | Win32** (EuroScope is a 32-bit app).
3. Press **Ctrl+Shift+B** to build.
4. The output `GOATscope.dll` will be in `Release\`.

---

## Loading in EuroScope

1. Start EuroScope and connect to a VATSIM session.
2. Go to **Other SET** → **Plug-ins**.
3. Click **Load a plugin from file** and browse to `GOATscope.dll`.
4. You should see the message:  
   `GOATscope v1.0.0 loaded. Click a tag item to open flight info.`

### Adding the tag item to your radar label

1. Open **Other SET** → **Radar display settings** → **Tag settings**.
2. Pick the label you use (e.g. the departure list label).
3. Add a new item → choose **GOATscope Info** from the dropdown.
4. Save and close.

Now every tracked aircraft will show a gold **[GOAT]** button in its tag.
Click it (or click the aircraft strip if you've mapped the function there)
to see the full info pop-up in the EuroScope message area.

---

## Adding more airports

Open `include/AirportDB.h` and add entries inside `PopulateAirportNames()`:

```cpp
db["XXXX"] = "My Airport Full Name";
```

Rebuild and reload the DLL.

---

## Known limitations

- **Magnetic variation** is not applied to the bearing; true bearing is used
  instead. For most VATSIM use this is fine, but you can integrate a World
  Magnetic Model lookup for precision.
- The pop-up appears in the EuroScope **message area**, not a floating
  window. A floating dialog (using Win32 `CreateWindowEx`) can be added in a
  later version.
- Altitude parsing handles `FL090` and `9000` formats; exotic formats like
  `A090` (metric) are treated as 0 ft.

---

## License

Free to use on VATSIM. Not for use on real-world ATC systems.
